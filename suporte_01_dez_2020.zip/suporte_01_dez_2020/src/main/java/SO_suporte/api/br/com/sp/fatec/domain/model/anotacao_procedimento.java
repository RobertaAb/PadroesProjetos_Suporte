package SO_suporte.api.br.com.sp.fatec.domain.model;

public class anotacao_procedimento {
private Long idAnotacao;
	private String titulo_anotacao;
	private String descricao_anotacao;
	private String datAnotacao;
	public Long getIdAnotacao() {
	return idAnotacao;
	}
	public String getTitulo_anotacao() {
		return titulo_anotacao;
	}
	public void setTitulo_anotacao(String titulo_anotacao) {
		this.titulo_anotacao = titulo_anotacao;
	}
	public String getDescricao_anotacao() {
		return descricao_anotacao;
	}
	public void setDescricao_anotacao(String descricao_anotacao) {
		this.descricao_anotacao = descricao_anotacao;
	}
	public String getDatAnotacao() {
		return datAnotacao;
	}
	public void setDatAnotacao(String datAnotacao) {
		this.datAnotacao = datAnotacao;
	}
	public void setIdAnotacao(Long idAnotacao) {
		this.idAnotacao = idAnotacao;
	}
}


