package SO_suporte.api.br.com.sp.fatec.controller;

import java.io.File;
import java.io.IOException;
import java.lang.ModuleLayer.Controller;
import java.util.Arrays;
import java.util.List;
import java.util.logging.Logger;

import com.sun.jmx.mbeanserver.Util;

import SO_suporte.api.br.com.sp.fatec.domain.model.SistemaOperacional;
import SO_suporte.api.br.com.sp.fatec.domain.model.anotacao_procedimento;
import SO_suporte.api.br.com.sp.fatec.domain.model.download;
import jdk.internal.loader.Loader;

@RestController
public class UsuarioController {

	@GetMapping("/Usuarios")
	public List<SistemaOperacional> listar(){
		var usuarioSO1 = new SistemaOperacional();
		usuarioSO1.setId(1L);
		usuarioSO1.setData("setembro/2020");
		usuarioSO1.setLink(" guia da Foca");
		usuarioSO1.setSO("Linux");
		usuarioSO1.setDescricao("UBUNTU");
				
		var usuarioSO2 = new SistemaOperacional();
		usuarioSO2.setId(2L);
		usuarioSO2.setData("setembro/2020");
		usuarioSO2.setLink(" Microsoft");
		usuarioSO2.setSO("Windows");
		usuarioSO2.setDescricao("Windows10");
		return Arrays.asList(usuarioSO1, usuarioSO2);		
	}
	public List<anotacao_procedimento> listar1(){
		var usuarioAnota1 = new anotacao_procedimento();
		usuarioAnota1.setIdAnotacao(1L);
		usuarioAnota1.setDatAnotacao("setembro/2020");
		usuarioAnota1.setTitulo_anotacao(" guia da Foca");
		usuarioAnota1.setDescricao_anotacao("Linux");
				
		var usuarioAnota2 = new anotacao_procedimento();
		usuarioAnota2.setIdAnotacao(2L);
		usuarioAnota2.setDatAnotacao("setembro/2020");
		usuarioAnota2.setTitulo_anotacao(" Microsoft");
		usuarioAnota2.setDescricao_anotacao("Windows");
		return Arrays.asList(usuarioAnota1, usuarioAnota2);		
	}


	public List<download> listar2(){

	static ModelAndView modelViewObj;

	private static Loader logger = Logger.getLogger(Controller.class);

	@RequestMapping(value = {"/", "fileDownload"}, method = RequestMethod.GET)
	public ModelAndView showUploadFileForm(ModelMap model) {
		modelViewObj = new ModelAndView("fileDownload");
		return  modelViewObj;
	}

	@RequestMapping(value = "downloadFile/pdf", method = RequestMethod.GET)
	public void downloadPdf(HttpServletRequest req,HttpServletResponse resp) throws IOException {
		String pdfFilePath = "", pdfFileName = "irregular-verbs.pdf";
		logger.info("Downloading A .PDF File From The Server ....!");

		/**** Get The Absolute Path Of The File ****/
		pdfFilePath = Util.getFilePath(req) + File.separator + pdfFileName;      
		logger.info("Absolute Path Of The .PDF File Is?= " + pdfFilePath);

		File downloadFile = new File(pdfFilePath);
		if(downloadFile.exists()) {
			Util.downloadFileProperties(req, resp, pdfFilePath, downloadFile);				
		} else {
			logger.info("Requested .PDF File Not Found At The Server ....!");
		}
	}
}
