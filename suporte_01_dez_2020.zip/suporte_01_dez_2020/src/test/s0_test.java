package test;

public class s0_test {

}
